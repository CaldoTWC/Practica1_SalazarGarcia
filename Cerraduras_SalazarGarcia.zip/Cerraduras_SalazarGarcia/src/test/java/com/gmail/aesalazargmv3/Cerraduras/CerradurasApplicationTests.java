package com.gmail.aesalazargmv3.Cerraduras;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class CerradurasApplicationTests {

	@Test
	void contextLoads() {
	}

}
