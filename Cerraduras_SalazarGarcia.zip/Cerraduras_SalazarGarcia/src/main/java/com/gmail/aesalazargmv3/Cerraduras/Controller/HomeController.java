package com.gmail.aesalazargmv3.Cerraduras.Controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.bind.annotation.RequestMapping;
import com.gmail.aesalazargmv3.Cerraduras.modelo.CerraduraService;

import java.util.Map;

@RestController
@RequestMapping("/api/cerradura")
public class HomeController {
	private final CerraduraService cerraduraService;

	@Autowired
	public HomeController(CerraduraService cerraduraService){
		this.cerraduraService = cerraduraService;
	}

	//Endpoint para la cerradura de Kleene (REST)
	@GetMapping("/estrella/{n}")
	public Map<String, String> getCerraduraKleene(@PathVariable ("n") int n) {
		return cerraduraService.kleeneCerradura(n);
	}

	@GetMapping("/positiva/{n}")
	public Map<String, String> getCerraduraPositiva(@PathVariable ("n") int n) {
		return cerraduraService.kleeneClausuraPositiva(n);
	}
	
}