package com.gmail.aesalazargmv3.Cerraduras.Controller;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.annotation.ComponentScan;;;

@SpringBootApplication(scanBasePackages = "com.gmail.aesalazargmv3.Cerraduras")
public class CerradurasApplication {

	public static void main(String[] args) {
		SpringApplication.run(CerradurasApplication.class, args);
	}

}
