package com.gmail.aesalazargmv3.Cerraduras.Controller;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import com.gmail.aesalazargmv3.Cerraduras.modelo.CerraduraService;

import java.util.Map;

@Controller
@RequestMapping("/cerradura")
public class VistaController {
    private final CerraduraService cerraduraService;

    public VistaController(CerraduraService cerraduraService) {
        this.cerraduraService = cerraduraService;
    }

    //Manejo de vista principal para ingresar "n"
    @GetMapping("/")
    public String mostrarFormulario() {
        return "formulario";
    }

    //Manejo de vista con Thymeleaf para mostrar los resultados
    @GetMapping
    public String mostrarCerraduras(@RequestParam("n") int n, Model model){

        //Obtener los resultados de la cerradura de Kleene y la positiva
        Map<String, String> kleene = cerraduraService.kleeneCerradura(n);
        Map<String, String> positiva = cerraduraService.kleeneClausuraPositiva(n);

        //Pasar los resultados al modelo para Thymeleaf
        model.addAttribute("numero", n);
        model.addAttribute("kleene", kleene.get("Σ^*"));
        model.addAttribute("positiva", positiva.get("Σ^*"));

        // Devolver la vista Thymeleaf 'cerradura.html'
        return "cerradura";
    }
    
}
